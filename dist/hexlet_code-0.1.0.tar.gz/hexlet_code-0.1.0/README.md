### Hexlet tests and linter status:
[![Actions Status](https://github.com/Fiklik/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/Fiklik/python-project-50/actions)

### Linter and tests status:
[![Actions Status](https://github.com/Fiklik/python-project-50/actions/workflows/lint.yml/badge.svg)](https://github.com/Fiklik/python-project-50/actions)

[![Actions Status](https://github.com/Fiklik/python-project-50/actions/workflows/test.yml/badge.svg)](https://github.com/Fiklik/python-project-50/actions)
