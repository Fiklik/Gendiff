### Hexlet tests and linter status:
[![Actions Status](https://github.com/Fiklik/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/Fiklik/python-project-50/actions)

### Linter and tests status:
[![Actions Status](https://github.com/Fiklik/python-project-50/actions/workflows/linter-and-test-check.yml/badge.svg)](https://github.com/Fiklik/python-project-50/actions)

### CodeClimate Maintainability and TestCoverage status:
[![Maintainability](https://api.codeclimate.com/v1/badges/f041e11c244da26f3187/maintainability)](https://codeclimate.com/github/Fiklik/python-project-50/maintainability) [![Test Coverage](https://api.codeclimate.com/v1/badges/f041e11c244da26f3187/test_coverage)](https://codeclimate.com/github/Fiklik/python-project-50/test_coverage)
